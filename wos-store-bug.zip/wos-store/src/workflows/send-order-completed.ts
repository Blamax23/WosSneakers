import { 
    createWorkflow, 
    WorkflowResponse,
} from "@medusajs/framework/workflows-sdk"
import { useQueryGraphStep } from "@medusajs/medusa/core-flows"
import { sendNotificationStep } from "./steps/send-notification"

type WorkflowInput = {
    id: string
}

export const sendOrderCompletedWorkflow = createWorkflow(
    "send-order-completed",
    ({ id }: WorkflowInput) => {
      // @ts-ignore
    const { data: orders } = useQueryGraphStep({
        entity: "order",
        fields: [
            "id",
            "display_id",
            "email",
            "currency_code",
            "total",
            "items.*",
            "shipping_address.*",
            "billing_address.*",
            "shipping_methods.*",
            "customer.*",
            "total",
            "subtotal",
            "discount_total",
            "shipping_total",
            "tax_total",
            "item_subtotal",
            "item_total",
            "item_tax_total",
        ],
        filters: {
            id,
        },
    })
    
        const notification = sendNotificationStep([{
            to: orders[0].email,
            channel: "email",
            template: "order-completed",
            data: {
            order: orders[0],
            },
        }])
    
        return new WorkflowResponse(notification)
    }
)